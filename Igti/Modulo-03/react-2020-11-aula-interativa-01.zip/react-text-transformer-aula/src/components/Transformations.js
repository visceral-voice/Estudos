import React, { Component } from 'react';

export default class Transformations extends Component {
  render() {
    return <div>{this.props.children}</div>;
  }
}
