export function formatDayMonth(value) {
  return value.toString().padStart(2, '0');
}
