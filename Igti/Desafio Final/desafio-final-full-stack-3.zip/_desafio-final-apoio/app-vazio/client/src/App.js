import React from 'react';

export default function App() {
  return <h1>Desafio Final do Bootcamp Full Stack</h1>;
}
